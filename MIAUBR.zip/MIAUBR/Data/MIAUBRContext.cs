﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MIAUBR.Models;

namespace MIAUBR.Data
{
    public class MIAUBRContext : DbContext
    { 
        public MIAUBRContext (DbContextOptions<MIAUBRContext> options)
            : base(options)
        {

        }

        public DbSet<MIAUBR.Models.Animais> Animais { get; set; }

        public DbSet<MIAUBR.Models.Usuario> Usuario { get; set; }

        public DbSet<MIAUBR.Models.Adocao> Adocao { get; set; }
    }
}
