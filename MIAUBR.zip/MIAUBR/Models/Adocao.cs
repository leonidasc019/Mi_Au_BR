﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MIAUBR.Models
{
    public class Adocao
    {
        public int Id { get; set; }
        public int fk_userId { get; set; }
        public int fk_animalId { get; set; }
    }
}
