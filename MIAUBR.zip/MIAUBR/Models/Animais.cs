﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MIAUBR.Models
{
    public class Animais
    {
        public int Id { get; set; }
        public string NomeAnimal { get; set; }
        public string Especie { get; set; }
        public string Genero { get; set; }
        public string Deficiencia { get; set; }
        public bool Vacinado { get; set; }
        public bool Castrado { get; set; }
        public string Temperamento { get; set; }
        public string observacao { get; set; }
        [DataType(DataType.Date, ErrorMessage = "Data em formato inválido")]
        public DateTime DataResgate { get; set; }
        [DataType(DataType.Date, ErrorMessage = "Data em formato inválido")]
        public DateTime? DataAdocao { get; set; }
        public int Idade { get; set; }
        public string pathFoto { get; set; }
        public string Porte { get; set; }
    }
}
